package org.goya.daw2.dwes.d2_ud3;


import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;

@Controller
public class AutentificadorController {

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    private final Map<String, String> usuarios = new HashMap<>();

    public AutentificadorController() {
        usuarios.put("admin", encoder.encode("1234"));
        usuarios.put("henry", encoder.encode("daw2"));
    }

    @GetMapping("/")
    public String inicio(HttpSession session, Model model) {
        return cargarPagina("Inicio", "/", session, model);
    }

    @GetMapping({"/pagina1", "/página1"})
    public String pagina1(HttpSession session, Model model) {
        return cargarPagina("Página 1", "/pagina1", session, model);
    }

    @GetMapping({"/pagina2", "/página2"})
    public String pagina2(HttpSession session, Model model) {
        return cargarPagina("Página 2", "/pagina2", session, model);
    }

    private String cargarPagina(String titulo, String rutaActual, HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        model.addAttribute("usuario", session.getAttribute("usuario"));
        model.addAttribute("titulo", titulo);
        model.addAttribute("rutaActual", rutaActual);
        return "pagina";
    }

    @GetMapping("/login")
    public String mostrarLogin(HttpSession session) {
        if (session.getAttribute("usuario") != null) {
            return "redirect:/";
        }
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam("usuario") String usuario,
                                @RequestParam("password") String password,
                                HttpSession session,
                                Model model) {
        String hashGuardado = usuarios.get(usuario);
        if (hashGuardado != null && encoder.matches(password, hashGuardado)) {
            session.setAttribute("usuario", usuario);
            return "redirect:/";
        }
        model.addAttribute("error", "Usuario o contraseña incorrectos.");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
