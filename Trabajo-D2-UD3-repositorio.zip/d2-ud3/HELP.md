# Read Me First
The following was discovered as part of building this project:

* The original package name 'org.goya.daw2.dwes.d2_ud3 ' is invalid and this project uses 'org.goya.daw2.dwes.d2_ud3' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/4.2.0/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.2.0/gradle-plugin/packaging-oci-image.html)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/4.2.0/reference/using/devtools.html)
* [Thymeleaf](https://docs.spring.io/spring-boot/4.2.0/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Spring Web](https://docs.spring.io/spring-boot/4.2.0/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

